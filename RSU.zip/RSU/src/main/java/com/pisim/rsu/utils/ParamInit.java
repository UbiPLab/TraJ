package com.pisim.rsu.utils;

import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.encryption.RSA;
import com.pisim.rsu.parameterUtil.IP;
import com.pisim.rsu.parameterUtil.parameter;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import org.ujmp.core.util.Base64;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.net.Inet4Address;
import java.util.*;

import static com.pisim.rsu.parameterUtil.parameter.*;
import static java.lang.System.exit;

public class ParamInit {
    public static void initFromFile(String pairingPath, String paramPath) throws Exception {
        Properties properties = new Properties();
        try {
//            init(pairingPath, paramPath);
            //从配置文件生成pairing
            pairing = PairingFactory.getPairing(pairingPath);
            G1 = pairing.getG1();
            G2 = pairing.getG2();
            GT = pairing.getGT();
            p = G1.getOrder();
            //从配置文件读取参数
            properties.load(new FileInputStream(paramPath));
            g = G1.newElementFromBytes(Base64.decode(properties.getProperty("g"))).getImmutable();
            X1 = G1.newElementFromBytes(Base64.decode(properties.getProperty("X1"))).getImmutable();
            X2 = G1.newElementFromBytes(Base64.decode(properties.getProperty("X2"))).getImmutable();
            X3 = G1.newElementFromBytes(Base64.decode(properties.getProperty("X3"))).getImmutable();
            rsuRsaPub = properties.getProperty("rsuRsaPub");
            rsuRsaPri = properties.getProperty("rsuRsaPri");
            elgamalA = new BigInteger(properties.getProperty("elgamalA"));
            elgamalP = new BigInteger(properties.getProperty("elgamalP"));
            tmspElgamalPublic = new BigInteger(properties.getProperty("tmspElgamalPublic"));


            gpk_g = G1.newElementFromBytes(Base64.decode(properties.getProperty("gpk_g"))).getImmutable();
            gpk_A = G1.newElementFromBytes(Base64.decode(properties.getProperty("gpk_A"))).getImmutable();
            gpk_B = G1.newElementFromBytes(Base64.decode(properties.getProperty("gpk_B"))).getImmutable();
            gpk_g2 = G1.newElementFromBytes(Base64.decode(properties.getProperty("gpk_g2"))).getImmutable();
            ZKPK_rou = new BigInteger(properties.getProperty("ZKPK_rou"));
            ZKPK_F = new BigInteger(properties.getProperty("ZKPK_F"));
            ZKPK_g = new BigInteger(properties.getProperty("ZKPK_g"));
            ZKPK_b = new BigInteger(properties.getProperty("ZKPK_b"));
            MC = Integer.parseInt(properties.getProperty("MC"));
            System.out.println("Info    ----    " + "从配置文件获取数据成功");
            //计算初试时间历元
            origin_te = (int) (System.currentTimeMillis() / (cycle));
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error   ----    " + "检测到配置文件出错，输入”r“重新生成参数，输入q退出");
            Scanner scanner = new Scanner(System.in);
            char c = scanner.next().charAt(0);
            if (c == 'r') {
                System.out.println("Info    ----    " + "开始重新输出参数");
                init(pairingPath, paramPath);
            } else {
                System.out.println("Info    ----    " + "退出");
                exit(0);
            }
        }
    }

    public static void init(String pairingPath, String paramPath) throws Exception {
        //生成双线性群
        pairing = PairingFactory.getPairing(pairingPath);
        G1 = pairing.getG1();
        G2 = pairing.getG2();
        GT = pairing.getGT();
        p = G1.getOrder();
        //向TA请求公开参数
        HttpThread httpThread = new HttpThread(IP.taIp + "getparameter", "", true);
        httpThread.start();
        httpThread.join();
        String result = parameter.result;
        JSONObject jsonObject = JSONObject.parseObject(result);

        //获取公共参数
        byte[] byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("gpk_g")));
        gpk_g = G2.newElementFromBytes(byte_temp);
        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("g")));
        g = G1.newElementFromBytes(byte_temp).getImmutable();
        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("X1")));
        X1 = G1.newElementFromBytes(byte_temp).getImmutable();
        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("X2")));
        X2 = G1.newElementFromBytes(byte_temp).getImmutable();
        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("X3")));
        X3 = G1.newElementFromBytes(byte_temp).getImmutable();
        taRsaPub = jsonObject.getString("taRsaPub");
        Map<String, String> RSAPair = RSA.generateRsaKeyPair();
        rsuRsaPub = RSAPair.get("publicKey");
        rsuRsaPri = RSAPair.get("privateKey");
        elgamalA = new BigInteger(jsonObject.getString("elgamalA"));
        elgamalP = new BigInteger(jsonObject.getString("elgamalP"));
        tmspElgamalPublic = new BigInteger(jsonObject.getString("tmspElgamalPublic"));


        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("gpk_A")));
        gpk_A = G2.newElementFromBytes(byte_temp);
        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("gpk_B")));
        gpk_B = G2.newElementFromBytes(byte_temp);
        byte_temp = Base64.decode((String) Objects.requireNonNull(jsonObject.get("gpk_g2")));
        gpk_g2 = G1.newElementFromBytes(byte_temp);
        MC = (int) jsonObject.get("MC");
        ZKPK_rou = jsonObject.getBigInteger("ZKPK_rou");
        ZKPK_F = jsonObject.getBigInteger("ZKPK_F");
        ZKPK_g = jsonObject.getBigInteger("ZKPK_g");
        ZKPK_b = jsonObject.getBigInteger("ZKPK_b");


        //将参数存储到文件里
        Properties properties = new Properties();
        properties.setProperty("rsuRsaPri", rsuRsaPri);
        properties.setProperty("rsuRsaPub", rsuRsaPub);
        properties.setProperty("g", Base64.encodeBytes(g.toBytes()));
        properties.setProperty("X1", Base64.encodeBytes(X1.toBytes()));
        properties.setProperty("X2", Base64.encodeBytes(X2.toBytes()));
        properties.setProperty("X3", Base64.encodeBytes(X3.toBytes()));
        properties.setProperty("elgamalA", elgamalA.toString());
        properties.setProperty("elgamalP", elgamalP.toString());
        properties.setProperty("tmspElgamalPublic", tmspElgamalPublic.toString());


        properties.setProperty("gpk_g", Base64.encodeBytes(gpk_g.toBytes()));
        properties.setProperty("gpk_A", Base64.encodeBytes(gpk_A.toBytes()));
        properties.setProperty("gpk_B", Base64.encodeBytes(gpk_B.toBytes()));
        properties.setProperty("gpk_g2", Base64.encodeBytes(gpk_g2.toBytes()));
        properties.setProperty("ZKPK_rou", ZKPK_rou.toString());
        properties.setProperty("ZKPK_F", ZKPK_F.toString());
        properties.setProperty("ZKPK_g", ZKPK_g.toString());
        properties.setProperty("ZKPK_b", ZKPK_b.toString());
        properties.setProperty("MC", String.valueOf(MC));


        properties.store(new FileOutputStream(paramPath), "参数");
        System.out.println("Info    ----    " + "参数初始化成功");

        //向TA注册
        JSONObject jsonObject1 = new JSONObject();
        jsonObject1.put("rsuRsaPub", rsuRsaPub);
        jsonObject1.put("address", Inet4Address.getLocalHost());
        jsonObject1.put("type", "RSU");
        HttpThread register = new HttpThread(IP.taIp + "RsuNspRegister", jsonObject1.toJSONString(), true);
        register.start();
        System.out.println("初始化请求参数完成");
        //计算初试时间历元
        origin_te = (int) (System.currentTimeMillis() / (cycle));
    }
}
