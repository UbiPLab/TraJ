package com.pisim.rsu.bean;

import java.sql.Timestamp;

public class DrivingReport {
    private int idreport;
    private String report_string;
    private String pId;
    private Timestamp timestamp;

    public void setId(int id) {
        this.idreport = id;
    }

    public int getId() {
        return idreport;
    }

    public String getReport_string() {
        return report_string;
    }

    public void setReport_string(String report_string) {
        this.report_string = report_string;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getpId() {
        return pId;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
}
