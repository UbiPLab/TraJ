package com.pisim.rsu.service.Impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.bean.DrivingReport;
import com.pisim.rsu.dao.DrivingReportDao;
import com.pisim.rsu.encryption.Hash;
import com.pisim.rsu.parameterUtil.parameter;
import com.pisim.rsu.service.CongestionInfoService;
import com.pisim.rsu.service.DrivingReportService;
import com.pisim.rsu.utils.Graph_;
import it.unisa.dia.gas.jpbc.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.pisim.rsu.utils.Graph;
import org.ujmp.core.util.Base64;

import java.sql.Timestamp;
import java.util.*;

import static com.pisim.rsu.controller.TraceDriver.Trace;
import static com.pisim.rsu.parameterUtil.parameter.*;

@Service
public class DrivingReportServiceImpl implements DrivingReportService {
    @Autowired
    private DrivingReportDao drivingReportDao;
    @Autowired
    CongestionInfoService congestionInfoService;
    @Autowired
    DrivingReportService drivingReportService;

    @Override
    public List<DrivingReport> getDrivingReportList(boolean getAllFromHistory) {
        return drivingReportDao.getDrivingReportList(getAllFromHistory);
    }

    @Override
    public boolean insertDrivingReport(JSONObject drivingReportJsonString, String pid, Timestamp timestamp) {
        return drivingReportDao.insertDrivingReport(drivingReportJsonString, pid, timestamp);
    }

    @Override
    public boolean deleteDrivingReport(String pid, boolean flag) {
        return drivingReportDao.deleteDrivingReport(pid, flag);
    }

    @Override
    public boolean filterFalseDrivingReport() {
        List<DrivingReport> drivingReportList = drivingReportDao.getDrivingReportList(false);
//        int n = secureRandom.nextInt(30);
//        for (int i = 0; i < 5; i++) {
//            drivingReportList.remove(secureRandom.nextInt(drivingReportList.size()));
//        }

        if (drivingReportList != null) {
//            RSUReportRequestValidCount = RSUReportRequestValidCount + drivingReportList.size();
//            RSUReportRequestValidCount_temp =  drivingReportList.size();
            //构造带权重距离图
            long startTime = System.nanoTime();
            Graph_ graph = constructGraph_(drivingReportList);
            long endTime = System.nanoTime();
//            System.out.println("构造带权图时间：" + (endTime - startTime));
            totalGenerateGraphTime += (endTime - startTime);

            //打印实验信息
//            int totalWeight = 0;
//            List<Graph_.Vertex> vertexList=graph.getVertexList();
//            for (Graph_.Vertex vertex : vertexList) {
//                System.out.println(vertex.getId() + ":" + vertex.getSunWeight());
//                totalWeight += vertex.getSunWeight();
//            }
//            System.out.println("nodeSize " + vertexList.size());
//            System.out.println("total weight " + totalWeight);
//            System.out.println("averageWeight "+totalWeight/vertexList.size());
//
//
//                        double trustSeed = 40;
            //graph.setVertexTrustValue(trustSeed, trustVertexList);

//            给指定的司机分配信任值（非随机分配）方法调用范例
//

//          1.给指定的单个司机（给出具体的pid）分配信任值
//            double trustValue = 40;
//            graph.setVertexTrustValueByPid("Bus", trustValue);

            //初试时给每个节点10点信任值
            for (Graph_.Vertex vertex : graph.getVertexList()) {
                vertex.setTrustValue(firstTrust);
            }
            //过滤图中的恶意节点
            startTime = System.nanoTime();
            graph.filterMaliciousVertex(parameter.iterations);
            endTime = System.nanoTime();
            System.out.println("30轮迭代花费时间：" + (endTime - startTime));
            totalIterationTime += (endTime - startTime);


//            List<Graph.Vertex> honestDriverVertexList = graph.getVertexList();
//            List<String> honestDriverPidList = new ArrayList<>();   //过滤后的诚实节点（贡献司机的pid）的集合
//            for (Graph.Vertex vertex : honestDriverVertexList) {
//                if (!honestDriverPidList.contains(vertex.getId())) {
//                    honestDriverPidList.add(vertex.getId());
//                }
//            }
            List<String> maliciousDriverPidList = new ArrayList<>();    //恶意节点的pid的集合
            for (Graph_.Vertex vertex : graph.getVertexList()) {
                if (vertex.getTrustValue() > parameter.cutoffThreshold) {
                    maliciousDriverPidList.add(vertex.getId());
                }
            }
            System.out.println("*恶意节点：" + maliciousDriverPidList);

//            for (DrivingReport drivingReport : drivingReportList) {
//                if (!honestDriverPidList.contains(drivingReport.getpId())) {
//                    JSONObject jsonObject = JSONObject.parseObject(drivingReport.getReport_string());
//                    Element REi1 = parameter.G1.newElementFromBytes(jsonObject.getBytes("REi1"));
//                    Element REi2 = parameter.G1.newElementFromBytes(jsonObject.getBytes("REi2"));
//                    Trace(REi1,REi2,jsonObject.getString("pidjs"),1);
//                    maliciousDriverPidList.add(drivingReport.getpId());
//                }
//            }

//            RSUReportValidCount_temp = RSUReportRequestValidCount_temp - maliciousDriverPidList.size();

            //从数据库中删除恶意节点对应的驾驶报告
//            for (String pid : maliciousDriverPidList) {
//                deleteDrivingReport(pid, true);
//            }

//            System.out.println("过滤虚假报告----虚假报告过滤成功！");
//            getCongestion getCongestion = new getCongestion();
//            getCongestion.generateCongestion(congestionInfoService, drivingReportService);

        } else {
            System.out.println("过滤虚假报告----无可用的路况报告，不需要进行过滤！");
        }

        return true;
    }

    @Override
    public boolean deleteOverdueDrivingReport(double validTime, boolean flag) {
        return drivingReportDao.deleteOverdueDrivingReport(validTime, flag);
    }

    /**
     * 构建带权重距离图
     *
     * @param drivingReportList 当前数据库中所有的交通报告
     * @return 返回带权重距离图
     */
    public static Graph_ constructGraph_(List<DrivingReport> drivingReportList) {
        //构建的加权图
        Graph_ graph_ = new Graph_(new ArrayList<Graph_.Vertex>(), new HashMap<Graph_.Vertex, List<Graph_.Edge>>());
        List<Graph_.Vertex> vertexList = new ArrayList<>();  //节点集
        Map<Graph_.Vertex, List<Graph_.Edge>> VertexEdgesListMap = new HashMap<>();  //图的每个顶点对应的无向边集
        List<JSONObject> pIdAndPIds = new ArrayList<>();
        //获取所有司机伪ID pId 及其通过握手获得的周围司机伪ID pIds
        for (DrivingReport drivingReport : drivingReportList) {
            JSONObject pIdAndPId = new JSONObject();
            pIdAndPId.put("pId", drivingReport.getpId());
            pIdAndPId.put("pIds", JSONObject.parseObject(drivingReport.getReport_string()).getJSONArray("pIds"));
            pIdAndPIds.add(pIdAndPId);
        }
        for (JSONObject pIdAndPId : pIdAndPIds) {
            //设置节点ID
            Graph_.Vertex vertex = new Graph_.Vertex(pIdAndPId.getString("pId"));
            //设置节点对应的无向边集合
            List<Graph_.Edge> edgeList = new ArrayList<>();

            //获取节点的握手伪ID集合
            JSONArray pIds = pIdAndPId.getJSONArray("pIds");
            //遍历处理当前节点握手集合中的每一个伪ID
            for (int i = 0; i < pIds.size(); i++) {
                //获取对应节点的伪ID
                String otherPId = pIds.getString(i);
                System.out.println(otherPId);
                //如果已经有和对应节点的无向边，就对边的权重+1
                boolean processedFlag = false;
                for (Graph_.Edge edge : edgeList) {
                    if (edge.getOneVertex().getId().equals(otherPId) || edge.getAnotherVertex().getId().equals(otherPId)) {
                        edge.setWeight(edge.getWeight() + 1);
                        processedFlag = true;
                    }
                }
                if (processedFlag) {
                    continue;
                }
                //判断对应节点的握手集合中是否包含当前节点
                for (JSONObject pIdAndPId_ : pIdAndPIds) {
                    //从pIdAndPId列表中中寻找对应节点
                    if (pIdAndPId_.getString("pId").equals(otherPId)) {
                        JSONArray anotherNodePIDs = pIdAndPId_.getJSONArray("pIds");
                        //对应节点的握手集合中包含当前节点
                        if (anotherNodePIDs.contains(pIdAndPId.getString("pId"))) {
                            //判断对应节点是否已创建
                            boolean flag = false;
                            for (Graph_.Vertex vertex1 : vertexList) {
                                if (vertex1.getId().equals(otherPId)) {
                                    //对应节点已创建
                                    flag = true;
                                    Graph_.Edge newEdge = new Graph_.Edge(vertex, vertex1, 1);
                                    //向当前节点的边集合添加一条无向边
                                    boolean addEdge = true;
                                    for (Graph_.Edge edge1 : edgeList) {
                                        if ((edge1.getOneVertex().getId().equals(newEdge.getOneVertex().getId())
                                                && edge1.getAnotherVertex().getId().equals(newEdge.getAnotherVertex().getId()))
                                                ||
                                                (edge1.getAnotherVertex().getId().equals(newEdge.getOneVertex().getId())
                                                        && edge1.getOneVertex().getId().equals(newEdge.getAnotherVertex().getId()))
                                        ) {
                                            edge1.setWeight(edge1.getWeight() + 1);
                                            addEdge = false;
                                        }
                                    }
                                    if (addEdge) {
                                        System.out.println("增加新边！");
                                        edgeList.add(newEdge);
                                    }
                                }
                            }
                            if (!flag) {
                                //对应节点未创建，创建一个对应节点
                                Graph_.Vertex anotherVertex = new Graph_.Vertex(otherPId);
                                //创建一个对应节点的边集合
                                List<Graph_.Edge> edgeList1 = new ArrayList<>();
                                Graph_.Edge newEdge = new Graph_.Edge(vertex, anotherVertex, 1);
                                edgeList1.add(newEdge);
//                              //将对应节点添加到节点列表中
//                              vertexList.add(anotherVertex);
                                //将对应节点和对应节点的边集合对应起来
                                VertexEdgesListMap.put(anotherVertex, edgeList1);

                                //向当前节点的边集合添加一条无向边
                                boolean addEdge = true;
                                for (Graph_.Edge edge1 : edgeList) {
                                    if ((edge1.getOneVertex().getId().equals(newEdge.getOneVertex().getId())
                                            && edge1.getAnotherVertex().getId().equals(newEdge.getAnotherVertex().getId()))
                                            ||
                                            (edge1.getAnotherVertex().getId().equals(newEdge.getOneVertex().getId())
                                                    && edge1.getOneVertex().getId().equals(newEdge.getAnotherVertex().getId()))
                                    ) {
                                        edge1.setWeight(edge1.getWeight() + 1);
                                        addEdge = false;
                                    }
                                }
                                if (addEdge) {
                                    edgeList.add(newEdge);
                                }

                            }
                        }

                    }
                }
            }
            // 将当前节点添加到节点列表中
            vertexList.add(vertex);
            //将当前节点和节点边集合对应起来
            VertexEdgesListMap.put(vertex, edgeList);
        }
        for(Graph_.Vertex vertex:vertexList){
            System.out.println(vertex.getId());
            for (Graph_.Edge edge:VertexEdgesListMap.get(vertex)){
                System.out.println("Edge:"+edge);
            }
        }
        //整合图和节点集
        Map<Graph_.Vertex, List<Graph_.Edge>> newVertexEdgesListMap = updateVertexEdgesListMap(vertexList, VertexEdgesListMap);
        List<Graph_.Vertex> newVertexList;
        newVertexList = updateVertexList(vertexList, newVertexEdgesListMap);
        updateVertexEdgesListMapSunWeight(newVertexList, newVertexEdgesListMap);
        graph_.setVertexList(newVertexList);
        graph_.setVertexEdgesListMap(newVertexEdgesListMap);
        return graph_;
    }

    public static Graph_ constructGraphDirectly_(){
        int N=500;//节点总数
        int n=10;//恶意节点数
        Graph_ graph_ = new Graph_(new ArrayList<Graph_.Vertex>(), new HashMap<Graph_.Vertex, List<Graph_.Edge>>());
        List<Graph_.Vertex> vertexList = new ArrayList<>();  //节点集
        Map<Graph_.Vertex, List<Graph_.Edge>> VertexEdgesListMap = new HashMap<>();  //图的每个顶点对应的无向边集
        return graph_;
    }


    /**
     * 更新顶点对应无向边中可能存在的数据疏漏
     *
     * @param newVertexList         顶点集
     * @param newVertexEdgesListMap 顶点对应无向边集
     */
    private static Map<Graph_.Vertex, List<Graph_.Edge>> updateVertexEdgesListMapSunWeight(List<Graph_.Vertex> newVertexList, Map<Graph_.Vertex, List<Graph_.Edge>> newVertexEdgesListMap) {
        //将顶点和对应权重综合对应起来
        HashMap<String, Integer> vertexWeight = new HashMap<String, Integer>();
        for (Graph_.Vertex vertex : newVertexList) {
            vertexWeight.put(vertex.getId(), vertex.getSunWeight());
        }
        //遍历顶点对应无向边集 查找可能的数据疏漏并补齐
        for (Map.Entry<Graph_.Vertex, List<Graph_.Edge>> itEntry : newVertexEdgesListMap.entrySet()) {
            List<Graph_.Edge> edgeList = itEntry.getValue();
            for (Graph_.Edge edge : edgeList) {
                if (edge.getOneVertex().getSunWeight() == 0) {
                    edge.getOneVertex().setSunWeight(vertexWeight.get(edge.getOneVertex().getId()));
                }
                if (edge.getAnotherVertex().getSunWeight() == 0) {
                    edge.getAnotherVertex().setSunWeight(vertexWeight.get(edge.getAnotherVertex().getId()));
                }
            }
        }
        return newVertexEdgesListMap;
    }

    private static List<Graph_.Vertex> updateVertexList(List<Graph_.Vertex> vertexList, Map<Graph_.Vertex, List<Graph_.Edge>> newVertexEdgesListMap) {
        for (Graph_.Vertex vertex : vertexList) {
            List<Graph_.Edge> edgeList = newVertexEdgesListMap.get(vertex);
            int sumWeight = 0;
            for (Graph_.Edge edge : edgeList) {
                sumWeight += edge.getWeight();
            }
            vertex.setSunWeight(sumWeight);
        }
        return vertexList;
    }

    //向节点边集合中添加边
    public static boolean addEdge(List<Graph_.Edge> edgeList, Graph_.Edge edge) {
        for (Graph_.Edge edge1 : edgeList) {
            if ((edge1.getOneVertex().getId().equals(edge.getOneVertex().getId())
                    && edge1.getAnotherVertex().getId().equals(edge.getAnotherVertex().getId()))
                    ||
                    (edge1.getAnotherVertex().getId().equals(edge.getOneVertex().getId())
                            && edge1.getOneVertex().getId().equals(edge.getAnotherVertex().getId()))
            ) {
                edge1.setWeight(edge1.getWeight() + 1);
                return false;
            }
        }
        edgeList.add(edge);
        return true;
    }

    public static Map<Graph_.Vertex, List<Graph_.Edge>> updateVertexEdgesListMap(List<Graph_.Vertex> vertexList, Map<Graph_.Vertex, List<Graph_.Edge>> VertexEdgesListMap) {
        Map<Graph_.Vertex, List<Graph_.Edge>> newVertexEdgesListMap = new HashMap<>();
        Iterator<Map.Entry<Graph_.Vertex, List<Graph_.Edge>>> iterator = VertexEdgesListMap.entrySet().iterator();
        List<Graph_.Edge> allEdgeList = new ArrayList<>();
        while (iterator.hasNext()) {
            //遍历每个节点和边集合
            Map.Entry<Graph_.Vertex, List<Graph_.Edge>> itEntry = iterator.next();
            //建立新的节点和新的边集合
            allEdgeList.addAll(itEntry.getValue());
        }
        for (Graph_.Vertex vertex : vertexList) {
            List<Graph_.Edge> newEdgeList = new ArrayList<>();
            for (Graph_.Edge edge : allEdgeList) {
                //判断节点是否属于该边
                if (edge.getOneVertex().getId().equals(vertex.getId()) || edge.getAnotherVertex().getId().equals(vertex.getId())) {
                    //判断新的边集合中是否有该边
                    int index = containsThisEdge(newEdgeList, edge);
                    //有该边，更新权重值
                    if (index != -1) {
                        newEdgeList.get(index).setWeight(newEdgeList.get(index).getWeight() + edge.getWeight());
                    } else {
                        if (edge.getOneVertex().getId().equals(vertex.getId())) {
                            Graph_.Edge newEdge = new Graph_.Edge(vertex, edge.getAnotherVertex(), edge.getWeight());
                            newEdgeList.add(newEdge);
                        } else {
                            Graph_.Edge newEdge = new Graph_.Edge(vertex, edge.getOneVertex(), edge.getWeight());
                            newEdgeList.add(newEdge);
                        }
                    }
                }

            }
            newVertexEdgesListMap.put(vertex, newEdgeList);
        }
        return newVertexEdgesListMap;

    }

    public static int containsThisEdge(List<Graph_.Edge> edgeList, Graph_.Edge edge) {
        for (int i = 0; i < edgeList.size(); i++) {
            Graph_.Edge edge1 = edgeList.get(i);
            if (
                    (edge1.getOneVertex().getId().equals(edge.getOneVertex().getId())
                            && edge1.getAnotherVertex().getId().equals(edge.getAnotherVertex().getId())
                    ) || (edge1.getOneVertex().getId().equals(edge.getAnotherVertex().getId())
                            && edge1.getAnotherVertex().getId().equals(edge.getOneVertex().getId())
                    )
            ) {
                return i;
            }
        }
        return -1;
    }

    //根据驾驶报告集构建加权邻近图
    public static Graph constructGraph(List<DrivingReport> drivingReportList) {
        //构建的加权图
        Graph graph = new Graph(new ArrayList<Graph.Vertex>(), new HashMap<Graph.Vertex, List<Graph.Edge>>());
        List<Graph.Vertex> vertexList = new ArrayList<>();  //节点集
        Map<Graph.Vertex, List<Graph.Edge>> VertexEdgesListMap = new HashMap<>();  //图的每个顶点对应的无向边集

//        List<String> pidListOfAllDrivers = new ArrayList<>();   //驾驶报告集中包含的所有司机的pid集合
//        for (DrivingReport drivingReport :drivingReportList) {
//            String cdPid = drivingReport.getPidj(); //发送驾驶报告的司机的pid
//            JSONObject jsonObject = JSON.parseObject(drivingReport.getReport_string());
//            //与发送驾驶报告的司机成功握手的司机的pid集合
//            List<String> pidOfHandshakeWithCdList = JSON.parseArray(jsonObject.getJSONArray("pId").toJSONString(), String.class);
//            //如果该发送司机的pid不在其中，则将其加入
//            if (!pidListOfAllDrivers.contains(cdPid)) {
//                pidListOfAllDrivers.add(cdPid);
//            }
//            //将pidOfHandshakeWithCdList中不在pidListOfAllDrivers的司机的pid也加入其中
//            for (String pid : pidOfHandshakeWithCdList) {
//                if (!pidListOfAllDrivers.contains(pid)) {
//                    pidListOfAllDrivers.add(pid);
//                }
//            }
//        }

        //驾驶报告集中贡献司机的pid的集合
        List<String> cdPidList = new ArrayList<>();
        for (DrivingReport drivingReport : drivingReportList) {
            //若为同一司机多次发送的驾驶报告，则只将其pid加入集合一次
            String drivingReportPid = drivingReport.getpId();
            if (!(cdPidList.contains(drivingReportPid))) {
                cdPidList.add(drivingReportPid);
            }
        }

        //每份驾驶报告中贡献司机的pid和与其成功成功握手的司机的pid集合的映射
        Map<String, List<String>> pidMap = new HashMap<>();
        for (DrivingReport drivingReport : drivingReportList) {
            JSONObject drivingReportJsonObject = JSON.parseObject(drivingReport.getReport_string());
            JSONArray pidListJsonArray = drivingReportJsonObject.getJSONArray("pIds");
            List<String> pidList = JSON.parseArray(pidListJsonArray.toJSONString(), String.class);
            //如果为同一个贡献司机发送的多份驾驶报告，则将其合并
            String cdPid = (String) drivingReportJsonObject.get("pId");
            if (pidMap.containsKey(cdPid)) {
                List<String> oldPidList = pidMap.get(cdPid);
                oldPidList.addAll(pidList);
            } else {
                pidMap.put(cdPid, pidList);
            }
        }


        Map<String, List<String>> newPidMap = new HashMap<>();
        newPidMap.putAll(pidMap);   //深拷贝原来的pidMap?
        for (Map.Entry<String, List<String>> map : pidMap.entrySet()) {
            String cdPid = map.getKey();
            List<String> pidList = map.getValue();
            for (String pid : pidList) {
                if (!cdPidList.contains(pid)) {
                    cdPidList.add(pid);
                    List<String> newPidList = new ArrayList<>();
                    newPidList.add(cdPid);
                    newPidMap.put(pid, newPidList);
                }
            }
        }

        //构建节点集
        for (String pid : cdPidList) {
            Graph.Vertex vertex = new Graph.Vertex(pid);
            vertexList.add(vertex);
        }

        //构建图的每个顶点对应的无向边集
        for (Map.Entry<String, List<String>> map : newPidMap.entrySet()) {
            Graph.Vertex oneVertex = new Graph.Vertex(map.getKey());    //发送驾驶报告的贡献司机对应的节点
            List<Graph.Edge> vertexEdgeList = new ArrayList<>();    //节点对应的无向边集（邻接表）
            //遍历每个节点对应的握手成功的pid集
            List<String> pidList = map.getValue();
            for (String pid : pidList) {
                Graph.Vertex anotherVertex = new Graph.Vertex(pid);
                Graph.Edge edge = new Graph.Edge(oneVertex, anotherVertex, 1); //构造边
                //如果该边已存在，则将该边对应的权重加1
                if (vertexEdgeList.contains(edge)) {
                    int index = vertexEdgeList.indexOf(edge);
                    int weight = vertexEdgeList.get(index).getWeight();
                    weight = weight + 1;
                    edge.setWeight(weight);
                    vertexEdgeList.set(index, edge);
                }
                //否则，将该边加入对应的无向边集中
                else {
                    vertexEdgeList.add(edge);
                }
            }
            VertexEdgesListMap.put(oneVertex, vertexEdgeList);
        }

        //解决节点存储的边一样（权重不同）时造成的图结构的不一致
        //Map<Graph.Vertex, List<Graph.Edge>> oldVertexEdgesListMap = new HashMap<>();
        //oldVertexEdgesListMap.putAll(VertexEdgesListMap);   //深拷贝？
        for (Map.Entry<Graph.Vertex, List<Graph.Edge>> map : VertexEdgesListMap.entrySet()) {
            Map<Graph.Vertex, List<Graph.Edge>> VertexEdgesListMapCopy = new HashMap<>();
            VertexEdgesListMapCopy.putAll(VertexEdgesListMap);  //深拷贝？
            Graph.Vertex vertex = map.getKey();
            List<Graph.Edge> edgeList = map.getValue();

            VertexEdgesListMapCopy.remove(vertex);  //去除当前节点及边列表后图中剩余的节点与边列表
            for (Map.Entry<Graph.Vertex, List<Graph.Edge>> remainMap : VertexEdgesListMapCopy.entrySet()) {
                Graph.Vertex remainVertex = remainMap.getKey();
                List<Graph.Edge> remainEdgeList = remainMap.getValue();

                for (Graph.Edge edge : edgeList) {
                    //如果有相同的边，则更新对应的权重值
                    if (remainEdgeList.contains(edge)) {
                        int remainIndex = remainEdgeList.indexOf(edge);
                        int remainWeight = remainEdgeList.get(remainIndex).getWeight();
                        int oldWeight = edge.getWeight();
                        edge.setWeight(oldWeight + remainWeight);
                        Graph.Edge remainEdge = remainEdgeList.get(remainIndex);
                        remainEdge.setWeight(remainWeight + oldWeight);
                    }
                }
            }
            break;
        }

        graph.setVertexList(vertexList);
        graph.setVertexEdgesListMap(VertexEdgesListMap);
        return graph;
    }

}
