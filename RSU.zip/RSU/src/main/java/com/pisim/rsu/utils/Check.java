package com.pisim.rsu.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.encryption.Hash;
import com.pisim.rsu.parameterUtil.parameter;
import it.unisa.dia.gas.jpbc.Element;
import org.ujmp.core.util.Base64;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.pisim.rsu.parameterUtil.parameter.*;
import static com.pisim.rsu.parameterUtil.parameter.g;
import static com.pisim.rsu.utils.RsuUtil.getMatrixArray;
import static com.pisim.rsu.utils.RsuUtil.verifyRequest;

/**
 * @author shouquan
 * @date 2021.4.19
 */
public class Check {
    public static int check(JSONObject data, boolean type) throws IOException {
        Element Tki = GT.newElementFromBytes(Base64.decode(data.getString("Tki"))).getImmutable();
        //验证是否为重复请求
//        BigInteger K = data.getBigInteger("K");
//        Element token = parameter.G1.newElementFromBytes(Base64.decode(data.getString("token")));
//        if (K.intValue() > MC) {
//            System.out.println("验证rdi导航查询或cdi提交报告请求失败----非法请求次数");
//            return 1;
//        }
        GroupOption groupOption = new GroupOption();
//        if (groupOption.verifyRequestCount(data.getJSONObject("blindedSiKey"), token, K, X3)) {
//            System.out.println("验证rdi导航查询或cdi提交报告请求失败----非法Token");
//            return 1;
//        }
//        if (parameter.Tokens.contains(new BigInteger(Hash.sha256(token.toString())))) {
//            System.out.println("验证rdi导航查询或cdi提交报告请求失败----Token重复使用");
//            return 1;
//        }

        if (type){
            if (tkiReport.contains(Tki.toBigInteger())) {
                System.out.println("验证rdi提交报告请求失败----请求假名重复使用");
                return 1;
            }
        }else {
            if (tkiQuery.contains(Tki.toBigInteger())) {
                System.out.println("验证rdi导航查询请求失败----请求假名重复使用");
                return 1;
            }
        }

        //验证匿名身份
        boolean flag = groupOption.verifyBlindedSiKey(data.getJSONObject("blindedSiKey"), g, X2, X3);
        if (flag) {
            //验证零知识证明
            flag = ZKPoK.verifyZKPoK(data.getJSONObject("zKPokResult"), data.getJSONObject("blindedSiKey"), parameter.pairing.pairing(g, g).getImmutable(), Tki, data.getBigInteger("Hi"));
            if (flag) {
                //正常请求
//                parameter.Tokens.add(token.toBigInteger());
                if(type){
                    tkiReport.add(Tki.toBigInteger());
                }else {

                    tkiQuery.add(Tki.toBigInteger());
                }
                System.out.println("验证rdi导航查询或cdi发起请求成功");
                return 2;
            } else {
                System.out.println("验证rdi导航查询或cdi提交报告请求失败----零知识证明错误");
                return 0;
            }
        } else {
            //身份无效
            System.out.println("验证rdi导航查询或cdi提交报告请求失败----匿名身份无效");
            return 0;
        }
    }

    //历史代码
//    private int check(JSONObject data) {
//        //验证请求次数是否异常
//        if (!parameter.grlpis.contains(data.getBigInteger("grlpi"))) {
//            System.out.println("验证rdi导航查询或cdi提交报告请求失败----限制假名错误");
//            return 1;
//        }
//        if (parameter.rlpis.contains(data.getBigInteger("rlpi"))) {
//            System.out.println("验证rdi导航查询或cdi提交报告请求失败----请求假名重复使用");
//            return 1;
//        } else {
//            parameter.rlpis.add(data.getBigInteger("rlpi"));
//        }
//        //验证零知识证明
//        boolean flag = verify_ZKPK(data.getBigInteger("grlpi"), data.getBigInteger("M"), data.getBigInteger("daierta"), parameter.ZKPK_F, data.getBigInteger("a1"));
//        if (flag) {
//            if (pairingCheck(data)) {
//                //正常请求
//                return 2;
//            } else {
//                System.out.println("验证rdi导航查询或cdi提交报告请求失败----零知识证明错误");
//                return 0;
//            }
//        } else {
//            //身份无效
//            return 0;
//        }
//
//    }

    public boolean pairingCheck(JSONObject data) {
        Element REi1 = parameter.G1.newElementFromBytes(data.getBytes("REi1"));
        Element REi2 = parameter.G1.newElementFromBytes(data.getBytes("REi2"));
        BigInteger ci = data.getBigInteger("ci");
        BigInteger ssi = data.getBigInteger("ssi");
        double[][] Query_EncKI = getMatrixArray(data.getJSONArray("Query_EncKI"), data.getIntValue("count"));
        BigInteger rlpi = data.getBigInteger("rlpi");
        int rci = data.getIntValue("rci");
        short indj = data.getShort("indj");
        List<String> pidjs = new ArrayList<>();
        JSONArray temp = data.getJSONArray("pidjs");
        for (Object o : temp) {
            pidjs.add((String) o);
        }
        byte[] xor_hsvjs = data.getBytes("xor_hsvjs");
        byte[] hsvj = data.getBytes("hsvj");
        String Mj_str = REi1.toString() + REi2.toString() + indj + pidjs.toString() + Arrays.toString(xor_hsvjs) + Arrays.toString(hsvj) + Arrays.deepToString(Query_EncKI) + rci;
        //零知识证明字符串
        String temp_ZKPK = data.getString("daierta") + data.getString("M") + data.getString("a1");
        return verifyRequest(REi1, REi2, Mj_str, ci, ssi, Query_EncKI, rlpi, rci, temp_ZKPK);
    }
}
