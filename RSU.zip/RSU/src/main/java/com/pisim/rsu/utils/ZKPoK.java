package com.pisim.rsu.utils;

import com.pisim.rsu.encryption.Hash;
import com.pisim.rsu.parameterUtil.parameter;
import com.pisim.rsu.parameterUtil.parameterLength;
import it.unisa.dia.gas.jpbc.Element;

import org.ujmp.core.util.Base64;
import com.alibaba.fastjson.*;

import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;

public class ZKPoK {
    //生成零知识证明
    public JSONObject generateZKPoK(BigInteger d, BigInteger r, Element g, Element Z) {
        JSONObject zKPok = new JSONObject();
        SecureRandom secureRandom = new SecureRandom();
        //生成零知识证明
        BigInteger rd = new BigInteger(parameterLength.rLength, secureRandom);
        BigInteger rr = new BigInteger(parameterLength.rLength, secureRandom);
        Element M = g.pow(d).mul(Z.pow(r));
        Element R = g.pow(rd).mul(Z.pow(rr));
        BigInteger c = new BigInteger(Hash.sha256(g.toString() + Z.toString() + M.toString() + R.toString()));
        zKPok.put("R", Base64.encodeBytes(R.toBytes()));
        zKPok.put("ad", c.multiply(d).add(rd).toString());
        zKPok.put("ar", c.multiply(r).add(rr).toString());
        zKPok.put("M", Base64.encodeBytes(M.toBytes()));
        return zKPok;
    }

    //验证零知识证明
    public boolean verifyZKPoK(JSONObject zKPok, Element g, Element Z) throws IOException {
        //获取参数
        Element M = parameter.G1.newElementFromBytes(Base64.decode(zKPok.getString("M")));

        Element R = parameter.G1.newElementFromBytes(Base64.decode(zKPok.getString("R")));
        BigInteger ad = new BigInteger(zKPok.getString("ad"));
        BigInteger ar = new BigInteger(zKPok.getString("ar"));
        BigInteger c = new BigInteger(Hash.sha256(g.toString() + Z.toString() + M.toString() + R.toString()));
        //验证是否成立
        return M.pow(c).mul(R).equals(g.pow(ad).mul(Z.pow(ar)));
    }

    //生成零知识证明
    public JSONObject generateZKPoK(JSONObject blindedSiKey, BigInteger d, BigInteger r, Element gT, Element Yt) throws IOException {
        JSONObject zKPok = new JSONObject();
        //计算v0,v1,v2,v3
        Element blindedSi1 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi1"))).getImmutable();
        Element blindedSi2 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi2"))).getImmutable();
        Element blindedSi3 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi3"))).getImmutable();
        Element blindedSi4 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi4"))).getImmutable();
        BigInteger r2Blinded = new BigInteger(blindedSiKey.getString("r2Blinded"));
        BigInteger r2BlindedReverse = r2Blinded.modInverse(parameter.p);
        Element v0 = parameter.pairing.pairing(parameter.g, blindedSi4).getImmutable();
        Element v1 = parameter.pairing.pairing(parameter.X1, blindedSi1).getImmutable();
        Element v2 = parameter.pairing.pairing(parameter.X1, blindedSi2).getImmutable();
        Element v3 = parameter.pairing.pairing(parameter.X1, blindedSi3).getImmutable();

        //生成零知识证明
        BigInteger rd = new BigInteger(parameterLength.rLength, parameter.secureRandom);
        BigInteger rr = new BigInteger(parameterLength.rLength, parameter.secureRandom);
        BigInteger rr_ = new BigInteger(parameterLength.rLength, parameter.secureRandom);

        Element R1 = v0.pow(rr_).mul(v2.pow(rd)).mul(v3.pow(rr)).getImmutable();
        Element R2 = Yt.pow(rd).getImmutable();

        BigInteger c = new BigInteger(Hash.sha256(v0.toString() + v1.toString() + v2.toString() + v3.toString() + R1.toString() + gT.toString() + Yt.toString() + R2.toString()));

        BigInteger ar_ = (c.multiply(r2BlindedReverse).add(rr_)).mod(parameter.p);
        BigInteger ad = (rd.subtract(c.multiply(d))).mod(parameter.p);
        BigInteger ar = (rr.subtract(c.multiply(r))).mod(parameter.p);

        //返回
        zKPok.put("R1", Base64.encodeBytes(R1.toBytes()));
        zKPok.put("ar_", ar_.toString());
        zKPok.put("ad", ad.toString());
        zKPok.put("ar", ar.toString());
        zKPok.put("R2", Base64.encodeBytes(R2.toBytes()));
        return zKPok;
    }

    //验证零知识证明
    public static boolean verifyZKPoK(JSONObject zKPok, JSONObject blindedSiKey, Element gT, Element Yt, BigInteger Hi) throws IOException {
        //计算v0,v1,v2,v3
        Element blindedSi1 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi1")));
        Element blindedSi2 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi2")));
        Element blindedSi3 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi3")));
        Element blindedSi4 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi4")));
        Element v0 = parameter.pairing.pairing(parameter.g, blindedSi4).getImmutable();
        Element v1 = parameter.pairing.pairing(parameter.X1, blindedSi1).getImmutable();
        Element v2 = parameter.pairing.pairing(parameter.X1, blindedSi2).getImmutable();
        Element v3 = parameter.pairing.pairing(parameter.X1, blindedSi3).getImmutable();

        Element R1 = parameter.GT.newElementFromBytes(Base64.decode(zKPok.getString("R1"))).getImmutable();
        Element R2 = parameter.GT.newElementFromBytes(Base64.decode(zKPok.getString("R2"))).getImmutable();

        BigInteger ar_ = new BigInteger(zKPok.getString("ar_")).mod(parameter.p);
        BigInteger ad = new BigInteger(zKPok.getString("ad")).mod(parameter.p);
        BigInteger ar = new BigInteger(zKPok.getString("ar")).mod(parameter.p);

        BigInteger c = new BigInteger(Hash.sha256(v0.toString() + v1.toString() + v2.toString() + v3.toString() + R1.toString() + gT.toString() + Yt.toString() + R2.toString()));

        Element temp1 = v1.pow(c).mul(R1);
        Element temp2 = v0.pow(ar_).mul(v2.pow(ad)).mul(v3.pow(ar));
//        System.out.println("temp1:"+temp1);
//        System.out.println("temp2:"+temp2);
        Element temp3 = (gT.mul(Yt.pow(BigInteger.valueOf(parameter.te)).negate())).pow(c).negate().mul(R2);
        Element temp4 = Yt.pow(ad);
//        System.out.println("temp3:"+temp3);
//        System.out.println("temp4:"+temp4);

        return temp1.isEqual(temp2) && temp3.isEqual(temp4);

    }
}
