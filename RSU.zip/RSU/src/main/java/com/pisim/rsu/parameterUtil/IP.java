package com.pisim.rsu.parameterUtil;

public class IP {
    //    public static String taIp ="http://114.55.33.26:6688/";
//    public static String nspIp = "http://39.97.107.100:6688/";

    public static String taIp = "http://192.168.31.215:6688/";
    public static String nspIp = "http://192.168.31.215:6600/";
}
