package com.pisim.rsu.controller;

import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.service.DrivingReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.pisim.rsu.parameterUtil.parameter;


@RestController
@RequestMapping("/getRsuPubKey")
public class RsuPubKeyController {
    @Autowired
    DrivingReportService drivingReportService;
    @RequestMapping(method = RequestMethod.GET)
    public JSONObject getRsuPubKey(){
        JSONObject data = new JSONObject();
        data.put("rsuRsaPub", parameter.rsuRsaPub);
        System.out.println("有人向我请求公钥了");
        return data;
    }
}
