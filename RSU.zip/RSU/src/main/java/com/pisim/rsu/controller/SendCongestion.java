package com.pisim.rsu.controller;

import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.bean.NaviQuery;
import com.pisim.rsu.service.CongestionInfoService;
import com.pisim.rsu.encryption.AES;
import com.pisim.rsu.encryption.RSA;
import com.pisim.rsu.service.NaviQueryInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.ujmp.core.util.Base64;

import java.sql.Timestamp;
import java.util.*;

import static com.pisim.rsu.encryption.AES.getStrKeyAES;
import static com.pisim.rsu.parameterUtil.parameter.*;
import static com.pisim.rsu.utils.Check.check;
import static com.pisim.rsu.utils.CongestionUtil.getCongestionFromTMSP;

@RestController
@RequestMapping("/getCongestion")
public class SendCongestion {

    @Autowired
    CongestionInfoService congestionInfoService;

    @Autowired
    NaviQueryInfoService naviQueryInfoService;

    @RequestMapping(method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject returnCongestionInfo(@RequestBody JSONObject jsonObject) {
        RSUNaviCount++;
        RSUNaviCount_temp++;
        try {
            String encAesKey = (String) jsonObject.get("encAESKey");
            String xigema = (String) jsonObject.get("sign");
            boolean flag = RSA.verify(encAesKey, xigema, (String) jsonObject.get("driverPub"));
            if (flag) {
                //解密AES密钥
                String AESKey = RSA.decrypt(encAesKey, rsuRsaPri);
                //解密数据内容
                byte[] encData = Base64.decode((String) jsonObject.get("encData"));
                String data_temp = new String(AES.decryptAES(encData, AESKey));
                JSONObject data = JSONObject.parseObject(data_temp);
                long startTime = System.currentTimeMillis();
                int checkResult = check(data, false);
                long endTime = System.currentTimeMillis();
                System.out.println("身份验证花费时间:" + (endTime - startTime));
                NaviQuery naviQuery = new NaviQuery();
//                naviQuery.setpId(data.getString("pId"));
                naviQuery.setBlindedSiKey(data.getString("blindedSiKey"));
                naviQuery.setETRi(data.getString("eTPis"));
                naviQuery.setTki(data.getString("Tki"));
                naviQuery.setzKPokResult(data.getString("zKPokResult"));
                naviQuery.setCount(data.getIntValue("count"));
                naviQuery.setTimestamp(new Timestamp(new Date().getTime()));
                naviQueryInfoService.insertNaviQueryInfo(naviQuery);
//                checkResult = 2;
                switch (checkResult) {
                    case 1: {
                        JSONObject result = new JSONObject();
                        result.put("result", "bad");
                        return result;
                    }
                    case 2: {
                        //验证通过，计算交通拥堵情况
                        RSUNaviValidCount++;
                        RSUNaviValidCount_temp++;
                        //获取导航查询请求的具体密文
                        System.out.println("接收到导航查询请求:" + data);
                        ArrayList<JSONObject> eTPis = data.getObject("eTPis", ArrayList.class);
                        System.out.println("向TMSP传递查询数据:" + eTPis);
                        //向TMSP发送路况查询
                        int[] congestion = getCongestionFromTMSP(eTPis);
                        //将TMSP返回结果加密并返回给客户端
                        System.out.println("向客户端发送查询结果:" + Arrays.toString(congestion));
                        JSONObject result = new JSONObject();
                        AESKey = getStrKeyAES();
                        encAesKey = RSA.encrypt(AESKey, (String) jsonObject.get("driverPub"));
                        xigema = RSA.signature(encAesKey, rsuRsaPri);
                        result.put("encAesKey", encAesKey);
                        result.put("sign", xigema);
                        JSONObject res_data = new JSONObject();
                        res_data.put("congestion", congestion);
                        byte[] res_encData = AES.encryptAES(res_data.toJSONString().getBytes(), AESKey);
                        result.put("encData", res_encData);
                        result.put("result", "success");
                        return result;
                    }
                    default: {
                        JSONObject result = new JSONObject();
                        result.put("result", "error");
                        return result;
                    }
                }

            }
        } catch (Exception e) {
            JSONObject result = new JSONObject();
            result.put("result", "error");
            return result;
        }
        JSONObject result = new JSONObject();
        result.put("result", "error");
        return result;
    }

}
