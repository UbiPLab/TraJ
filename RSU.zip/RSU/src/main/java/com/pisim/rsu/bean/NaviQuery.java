package com.pisim.rsu.bean;

import java.sql.Timestamp;

public class NaviQuery {
    private int id;
    private String pId;
    private String ETRi;
    private String zKPokResult;
    private String blindedSiKey;
    private String Tki;
    private Timestamp timestamp;
    int count = 0;

    public int getId() {
        return id;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setBlindedSiKey(String blindedSiKey) {
        this.blindedSiKey = blindedSiKey;
    }

    public void setETRi(String ETRi) {
        this.ETRi = ETRi;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public void setTki(String tki) {
        Tki = tki;
    }

    public void setzKPokResult(String zKPokResult) {
        this.zKPokResult = zKPokResult;
    }

    public String getETRi() {
        return ETRi;
    }

    public String getBlindedSiKey() {
        return blindedSiKey;
    }

    public String getpId() {
        return pId;
    }

    public String getTki() {
        return Tki;
    }

    public String getzKPokResult() {
        return zKPokResult;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }
}
