package com.pisim.rsu.utils;

import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.parameterUtil.parameter;
import com.pisim.rsu.parameterUtil.parameterLength;
import it.unisa.dia.gas.jpbc.Element;


import org.ujmp.core.util.Base64;

import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.HashMap;

/**
 * @author shouquan
 * @date 2021.3.24
 */
public class GroupOption {

    public boolean verifyGroupSiKey(JSONObject siKey, BigInteger r1, BigInteger r2) throws IOException {
        boolean flag = true;
        //获取GroupSiKey
        Element si1 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si1")));
        Element si2 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si2")));
        Element si3 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si3")));
        Element si4 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si4")));
        //依次验证
        if (si1.isEqual(parameter.G1.newOneElement())) {
            flag = false;
        }
        if (flag) {
            if (!parameter.pairing.pairing(parameter.g, si2).isEqual(parameter.pairing.pairing(parameter.X2, si1))) {
                flag = false;
            }
        }
        if (flag) {
            if (!parameter.pairing.pairing(parameter.g, si3).isEqual(parameter.pairing.pairing(parameter.X3, si2))) {
                flag = false;
            }
        }
        Element temp = parameter.pairing.pairing(parameter.X1, si1).mul(parameter.pairing.pairing(parameter.X1, si2).pow(r1)).mul(parameter.pairing.pairing(parameter.X1, si3).pow(r2));
        if (flag) {
            if (!parameter.pairing.pairing(parameter.g, si4).equals(temp)) {
                flag = false;
            }
        }
        return flag;
    }

    public JSONObject generateBlindedSi(JSONObject siKey) throws IOException {
        //获取GroupSiKey
        Element si1 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si1")));
        Element si2 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si2")));
        Element si3 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si3")));
        Element si4 = parameter.G1.newElementFromBytes(Base64.decode(siKey.getString("si4")));
        //盲化
        BigInteger r1Blinded = new BigInteger(parameterLength.rLength, parameter.secureRandom);
        BigInteger r2Blinded = new BigInteger(parameterLength.rLength, parameter.secureRandom);
        Element blindedSi1 = si1.pow(r1Blinded);
        Element blindedSi2 = si2.pow(r1Blinded);
        Element blindedSi3 = si3.pow(r1Blinded);
        Element blindedSi4 = si4.pow(r1Blinded.multiply(r2Blinded));
        //整理并返回
        JSONObject blindedSiKey = new JSONObject();
        blindedSiKey.put("blindedSi1", Base64.encodeBytes(blindedSi1.toBytes()));
        blindedSiKey.put("blindedSi2", Base64.encodeBytes(blindedSi2.toBytes()));
        blindedSiKey.put("blindedSi3", Base64.encodeBytes(blindedSi3.toBytes()));
        blindedSiKey.put("blindedSi4", Base64.encodeBytes(blindedSi4.toBytes()));
        blindedSiKey.put("r1Blinded", r1Blinded.toString());
        blindedSiKey.put("r2Blinded", r2Blinded.toString());
        return blindedSiKey;
    }

    public boolean verifyBlindedSiKey(JSONObject blindedSiKey, Element g, Element Y, Element Z) throws IOException {
        Element blindedSi1 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi1")));
        Element blindedSi2 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi2")));
        Element blindedSi3 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi3")));
        //验证
        if (blindedSi1.isEqual(parameter.G1.newOneElement())) {
            return false;
        }
        if (!parameter.pairing.pairing(g, blindedSi2).isEqual(parameter.pairing.pairing(Y, blindedSi1))) {
            return false;
        }
        return parameter.pairing.pairing(g, blindedSi3).isEqual(parameter.pairing.pairing(Z, blindedSi2));

    }
    /**
     * 验证请求次数
     * 不合法则返回false
     */
    public boolean verifyRequestCount(JSONObject blindedSiKey,Element token, BigInteger K,Element Z) throws IOException {
        //验证
        Element blindedSi2 = parameter.G1.newElementFromBytes(Base64.decode(blindedSiKey.getString("blindedSi2"))).getImmutable();

        return token.equals(parameter.pairing.pairing(Z,blindedSi2).pow(K));
    }
}
