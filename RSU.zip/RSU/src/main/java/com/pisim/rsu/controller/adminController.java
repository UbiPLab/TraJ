package com.pisim.rsu.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.bean.DrivingReport;
import com.pisim.rsu.bean.NaviQuery;
import com.pisim.rsu.service.DrivingReportService;
import com.pisim.rsu.service.NaviQueryInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.pisim.rsu.parameterUtil.parameter.*;


@RestController
@RequestMapping("/RSUInfo")
public class adminController {
    @Autowired
    DrivingReportService drivingReportService;
    @Autowired
    NaviQueryInfoService naviQueryInfoService;

    @RequestMapping(method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject returnRSUInfo() {
        JSONObject result = new JSONObject();
        result.put("RSUNaviCount", RSUNaviCount);
        result.put("RSUNaviValidCount", RSUNaviValidCount);
        result.put("RSUReportRequestCount", RSUReportRequestCount);
        result.put("RSUReportRequestValidCount", RSUReportRequestValidCount);
        result.put("RSUReportValidCount", RSUReportValidCount);
        result.put("RSUNaviCount_Last", RSUNaviCount_Last);
        result.put("RSUNaviValidCount_Last", RSUNaviValidCount_Last);
        result.put("RSUReportRequestCount_Last", RSUReportRequestCount_Last);
        result.put("RSUReportRequestValidCount_Last", RSUReportRequestValidCount_Last);
        result.put("RSUReportValidCount_Last", RSUReportValidCount_Last);
        result.put("RSUReportRequestValidCount_temp", RSUReportRequestValidCount_temp);
        result.put("RSUReportMaliciousCount", RSUReportMaliciousCount);
        result.put("RSUNaviPointCount_temp", RSUNaviPointCount_temp);

        List<DrivingReport> drivingReports = drivingReportService.getDrivingReportList(false);
        List<NaviQuery> naviQueryList = naviQueryInfoService.getNaviQueryInfoList();
        if (drivingReports != null) {
            result.put("RSUReport", parseStringReport(drivingReports));
        } else {
            result.put("RSUReport", null);
        }
        if (naviQueryList != null) {
            result.put("RSUNavi", parseStringNavi(naviQueryList));
        } else {
            result.put("RSUNavi", null);
        }
        result.put("te", te - origin_te);
        return result;
    }

    private JSONArray parseStringReport(List<DrivingReport> drivingReports) {
        JSONArray jsonArray = new JSONArray();
        for (DrivingReport drivingReport : drivingReports) {
            JSONObject jsonObject = new JSONObject();
            JSONObject jsonObject_temp = JSONObject.parseObject(drivingReport.getReport_string());
            jsonObject.put("pId", jsonObject_temp.getString("pId"));
            jsonObject.put("blindedSiKey", jsonObject_temp.getString("blindedSiKey"));
            jsonObject.put("Tki", jsonObject_temp.getString("Tki"));
            jsonObject.put("ETRi", jsonObject_temp.getString("ETRi"));
            jsonObject.put("zKPokResult", jsonObject_temp.getString("zKPokResult"));
            jsonObject.put("pIds", jsonObject_temp.getString("pIds"));
            jsonObject.put("timestamp", drivingReport.getTimestamp());
            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }

    private JSONArray parseStringNavi(List<NaviQuery> drivingNaviQuerys) {
        JSONArray jsonArray = new JSONArray();
        for (NaviQuery drivingNaviQuery : drivingNaviQuerys) {
            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("pId", drivingNaviQuery.getpId());
            jsonObject.put("blindedSiKey", drivingNaviQuery.getBlindedSiKey());
            jsonObject.put("Tki", drivingNaviQuery.getTki());
            jsonObject.put("ETRi", drivingNaviQuery.getETRi());
            jsonObject.put("zKPokResult", drivingNaviQuery.getzKPokResult());
            jsonObject.put("timestamp", drivingNaviQuery.getTimestamp());
            jsonObject.put("count",drivingNaviQuery.getCount());
            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }


}
