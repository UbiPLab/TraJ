package com.pisim.rsu.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.bean.CongestionInfo;
import com.pisim.rsu.bean.DrivingReport;
import com.pisim.rsu.parameterUtil.IP;
import com.pisim.rsu.service.CongestionInfoService;
import com.pisim.rsu.service.DrivingReportService;
import com.pisim.rsu.encryption.AES;
import com.pisim.rsu.encryption.RSA;
import com.pisim.rsu.parameterUtil.parameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;
import org.ujmp.core.util.Base64;

import java.sql.Timestamp;
import java.util.*;

import static com.pisim.rsu.encryption.AES.getStrKeyAES;
import static com.pisim.rsu.encryption.Fuzzy_search.Search;
import static com.pisim.rsu.parameterUtil.IP.nspIp;
import static com.pisim.rsu.parameterUtil.parameter.*;
import static com.pisim.rsu.utils.RsuUtil.getMatrixArray;

public class CongestionUtil {
    @Autowired
    CongestionInfoService congestionInfoService;

    public void sendATRToTMSP(JSONObject[] ATR) {
        JSONObject Data = new JSONObject();
        Data.put("ATR", ATR);
        sendDataToTMSP("sendCongestion", Data, false);

    }

    public void sendCongestionToTMSP(List<CongestionInfo> congestionInfos) {
        JSONObject Data = new JSONObject();
        Data.put("congestions", congestionInfos);
        sendDataToTMSP("sendCongestion", Data, false);
    }

    public static int[] getCongestionFromTMSP(ArrayList<JSONObject> eTPis) {
        JSONObject Data = new JSONObject();
        Data.put("eTPis", eTPis);
        JSONObject result = sendDataToTMSP("getCongestion", Data, true);
        JSONArray jsonArray = result.getJSONArray("congestion");
        int[] congestion = new int[eTPis.size()];
        for (int i = 0; i < jsonArray.size(); i++) {
            int temp = (int) jsonArray.get(i);
            if (temp<=5){
                congestion[i] = 0;
            }
            if (temp>5&&temp<10){
                congestion[i] = 1;
            }
            if (temp>10&&temp<20){
                congestion[i] = 2;
            }
            if (temp>=20){
                congestion[i] = 3;
            }
        }
        return congestion;
    }

    public short[] getCongestion(double[][] Index_EncKI, double[] threshold, int count) {
        try {
            System.out.println("查询点的个数" + count / 2);
            RSUNaviPointCount_temp = count / 2;
            short[] congestion = new short[count / 2];
            List<Integer> record = new ArrayList<>();
            List<CongestionInfo> congestionInfos = congestionInfoService.getCongestionInfoList();
            if (congestionInfos != null) {
                boolean flag = false;
                Matrix Matrix_Index = DenseMatrix.Factory.importFromArray(Index_EncKI);
                for (int i = 0; i < count / 2; i = i + 1) {
                    for (CongestionInfo congestionInfo : congestionInfos) {
                        JSONArray jsonArray = JSON.parseArray(congestionInfo.getQueryindex());
                        double ThresholdQuery = congestionInfo.getThresholdQuery();
                        double[][] Index_Query = getMatrixArray(jsonArray, 2);
                        Matrix Matrix_Query = DenseMatrix.Factory.importFromArray(Index_Query);
                        double result = Search(Matrix_Index, Matrix_Query, i * 2);
                        int temp = (int) result;
                        if ((result - temp) > 0.5) {
                            temp++;
                        }
                        if (temp == (int) threshold[i] && temp == (int) ThresholdQuery) {
                            System.out.println("当前点索引匹配成功" + i + "***************" + temp);
                            congestion[i] = congestionInfo.getIndj();
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        record.add(i);
                        congestion[i] = 0;
                    }
                    flag = false;
                }
                //组装要发给NSP的数据
                double[][] findFromTa = new double[Index_EncKI.length][record.size() * 2];
                for (int i = 0; i < record.size() * 2; i = i + 2) {
                    for (int k = 0; k < Index_EncKI.length; k++) {
                        findFromTa[k][i] = Index_EncKI[k][record.get(i / 2)];
                        findFromTa[k][i + 1] = Index_EncKI[k][record.get(i / 2) + 1];
                    }
                }
                double[] threshold_temp = new double[record.size()];
                for (int i = 0; i < record.size(); i++) {
                    threshold_temp[i] = threshold[record.get(i)];
                }
                //向NSP发起查询
                JSONArray jsonArray = SearchFromNsp(findFromTa, threshold_temp);
                //将从NSP查询的结果与RSU查询的结果组合
                if (jsonArray != null) {
                    int i = 0;
                    for (Integer integer : record) {
                        congestion[integer] = jsonArray.getShort(i);
                        i++;
                    }
                }
                //返回路况查询结果
                System.out.println("从NSP请求到的结果:" + Arrays.toString(congestion));
                return congestion;
            } else {
                //本地数据库为空，直接向NSP发起查询
                JSONArray jsonArray = SearchFromNsp(Index_EncKI, threshold);
                for (int i = 0; i < jsonArray.size(); i++) {
                    congestion[i] = jsonArray.getShort(i);
                }
                return congestion;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new short[count];
        }

    }

    public JSONObject[] generateATR(DrivingReportService drivingReportService) {
        try {
            //从数据库获取所有报告
            List<DrivingReport> drivingReportList = drivingReportService.getDrivingReportList(true);
            //从报告中获取ETRi
            JSONObject[] ETRis = new JSONObject[drivingReportList.size()];
            JSONObject tempJsonObject;
            int i = 0;
            for (DrivingReport drivingReport : drivingReportList) {
                tempJsonObject = JSON.parseObject(drivingReport.getReport_string());
                ETRis[i] = (tempJsonObject.getJSONObject("ETRi"));
                i++;
            }
            //费雪耶兹随机置乱
            long startTime = System.currentTimeMillis();
            int size = ETRis.length;
            int temp;
            JSONObject tempETRi;
            for (int k = size - 1; k > 0; k--) {
                temp = secureRandom.nextInt(size);
                tempETRi = ETRis[k];
                ETRis[k] = ETRis[temp];
                ETRis[temp] = tempETRi;
            }
            long endTime = System.currentTimeMillis();
            System.out.println("置乱花费时间"+(endTime-startTime));
            return ETRis;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void generateCongestion(CongestionInfoService congestionInfoService, DrivingReportService drivingReportService) {
        try {
            JSONObject jsonObject;
            CongestionInfo congestionInfo = new CongestionInfo();
            List<CongestionInfo> congestionInfos = new ArrayList<>();
            List<DrivingReport> drivingReportList = drivingReportService.getDrivingReportList(true);
            if (drivingReportList != null) {
                RSUReportValidCount_temp = drivingReportList.size();
                RSUReportValidCount = RSUReportValidCount + RSUReportValidCount_temp;
                RSUReportMaliciousCount = RSUReportRequestValidCount - RSUReportValidCount;
                System.out.println("虚假路况报告数量" + RSUReportMaliciousCount);
                for (DrivingReport drivingReport : drivingReportList) {
                    jsonObject = JSON.parseObject(drivingReport.getReport_string());
                    congestionInfo.setIndj((short) jsonObject.getIntValue("indj"));
                    JSONArray jsonArray = jsonObject.getJSONArray("Query_EncKI");
                    congestionInfo.setQueryindex(jsonArray.toString());
                    congestionInfo.setThresholdQuery(jsonObject.getDouble("thresholdQuery"));
                    //此处获取的是系统时间，当存入mysql中时，mysql采用UTC时间，比系统时间慢8个小时，不过从中读出后timestamp类型会自动进行转换以与系统时间对应（加8小时）
                    Timestamp timestamp = new Timestamp(new Date().getTime());
                    congestionInfo.setTimestamp(timestamp);
                    congestionInfos.add(congestionInfo);
                }
                congestionInfoService.insertCongestionInfo(congestionInfos);
                sendCongestionToTMSP(congestionInfos);
            } else {
                System.out.println("生成路况信息-----数据库中无可用的驾驶报告，未生成交通拥堵信息");
                RSUReportMaliciousCount = RSUReportRequestValidCount - RSUReportValidCount;
                System.out.println("虚假路况报告数量" + RSUReportMaliciousCount);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //向NSP发起请求
    private JSONArray SearchFromNsp(double[][] findFromTa, double[] threshold) {
        try {
            JSONObject data = new JSONObject();
            data.put("Index_EncKiI", findFromTa);
            data.put("count", threshold.length * 2);
            data.put("threshold", threshold);
            String AESKey = getStrKeyAES();
            byte[] encData = AES.encryptAES(data.toJSONString().getBytes(), AESKey);
            HttpThread getRsuPubKey = new HttpThread(nspIp + "getNspPubKey", false);
            getRsuPubKey.start();
            getRsuPubKey.join();
            parameter.NSP_rsa_pub = JSONObject.parseObject(parameter.result).getString("NSP_rsa_pub");
            String encAESKey = RSA.encrypt(AESKey, parameter.NSP_rsa_pub);
            JSONObject jsonObject = new JSONObject();
            //对加密后的对称密钥签名 并添加入json
            jsonObject.put("sign", RSA.signature(encAESKey, rsuRsaPri));
            jsonObject.put("encData", Base64.encodeBytes(encData));
            jsonObject.put("encAESKey", encAESKey);
            jsonObject.put("rsuRsaPub", rsuRsaPub);
            HttpThread httpThread = new HttpThread(IP.nspIp + "getCongestion", jsonObject.toJSONString(), true);
            httpThread.start();
            httpThread.join();
            //解析收到的数据
            JSONObject result = JSONObject.parseObject(parameter.result);
            if ("success".equals(result.getString("result"))) {
                encAESKey = (String) result.get("encAESKey");
                String xigema = (String) result.get("sign");
                assert encAESKey != null;
                boolean flag = RSA.verify(encAESKey, xigema, parameter.NSP_rsa_pub);
                if (flag) {
                    //解密AES密钥
                    AESKey = RSA.decrypt(encAESKey, rsuRsaPri);
                    encData = Base64.decode((String) Objects.requireNonNull(result.get("encData")));
                    //解密接收到的数据
                    String data_temp = new String(AES.decryptAES(encData, AESKey));
                    data = JSONObject.parseObject(data_temp);
                    return data.getJSONArray("congestion");
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 向TMSP发送数据
     *
     * @param data 数据内容
     * @param flag 如果为true 则表示需要等待响应，为false不等待响应
     * @return 响应结果，不需要响应时返回空
     */
    public static JSONObject sendDataToTMSP(String url, JSONObject data, boolean flag) {
        try {
            if (tmspRsaPub == null) {
                HttpThread getRsuPubKey = new HttpThread(nspIp + "getTmspPubKey", false);
                getRsuPubKey.start();
                getRsuPubKey.join();
                tmspRsaPub = JSONObject.parseObject(parameter.result).getString("tmspRsaPub");
            }
            //随机获取对称密钥
            String aesKey = getStrKeyAES();
            //对称密钥加密
            String encAesKey = RSA.encrypt(aesKey, parameter.tmspRsaPub);
            //对加密的对称密钥进行签名
            String xigema = RSA.signature(encAesKey, rsuRsaPri);
            //对要发送的数据进行加密
            byte[] encData = AES.encryptAES(data.toJSONString().getBytes(), aesKey);
            //组装要发送的jsonObject
            JSONObject encJsonObject = new JSONObject();
            encJsonObject.put("encAesKey", encAesKey);
            encJsonObject.put("sign", xigema);
            encJsonObject.put("rsuRsaPub", rsuRsaPub);
            encJsonObject.put("encData", encData);
            HttpThread httpThread = new HttpThread(nspIp + url, encJsonObject.toJSONString(), true);
            httpThread.start();
            //flag = false表示不需要接收响应
            if (flag) {
                httpThread.join();
                //解析收到的数据
                JSONObject result = JSONObject.parseObject(parameter.result);
                //监测服务器处理是否出错
                if ("success".equals(result.getString("result"))) {
                    encAesKey = (String) result.get("encAesKey");
                    xigema = (String) result.get("sign");
                    assert encAesKey != null;
                    //验证签名
                    flag = RSA.verify(encAesKey, xigema, tmspRsaPub);
                    if (flag) {
                        //解密AES密钥
                        aesKey = RSA.decrypt(encAesKey, rsuRsaPri);
                        encData = Base64.decode((String) Objects.requireNonNull(result.get("encData")));
                        //解密接收到的数据
                        String data_temp = new String(AES.decryptAES(encData, aesKey));
                        //将数据解析成jsonObject形式并返回
                        data = JSONObject.parseObject(data_temp);
                        return data;
                    }
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //非正常情况都返回null
        return null;
    }

}
