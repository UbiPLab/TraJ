package com.pisim.rsu.controller;

import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.service.CongestionInfoService;
import com.pisim.rsu.service.DrivingReportService;
import com.pisim.rsu.encryption.AES;
import com.pisim.rsu.encryption.RSA;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.ujmp.core.util.Base64;
import java.sql.Timestamp;
import java.util.*;


import static com.pisim.rsu.parameterUtil.parameter.*;
import static com.pisim.rsu.utils.Check.check;

@RestController
@RequestMapping("/submitReport")
public class ReceiveReport {
    final
    CongestionInfoService congestionInfoService;
    final
    DrivingReportService drivingReportService;

    public ReceiveReport(CongestionInfoService congestionInfoService, DrivingReportService drivingReportService) {
        this.congestionInfoService = congestionInfoService;
        this.drivingReportService = drivingReportService;
    }

    @RequestMapping(method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public JSONObject returnCongestionInfo(@RequestBody JSONObject jsonObject) {
        RSUReportRequestCount++;
        RSUReportRequestCount_temp++;
        try {
            String encAESKey = (String) jsonObject.get("encAESKey");
            String xigema = (String) jsonObject.get("sign");
            boolean flag = RSA.verify(encAESKey, xigema, (String) jsonObject.get("driverPub"));
            if (flag) {
                //解密AES密钥
                String AESKey = RSA.decrypt(encAESKey, rsuRsaPri);
                //解密数据内容
                byte[] encData = Base64.decode((String) jsonObject.get("encData"));
                String data_temp = new String(AES.decryptAES(encData, AESKey));
                JSONObject data = JSONObject.parseObject(data_temp);
                long startTime = System.currentTimeMillis();
                int checkResult = check(data,true);
                long endTime = System.currentTimeMillis();
                System.out.println("身份验证花费时间:"+(endTime-startTime));
                switch (checkResult) {
                    case 1: {
                        //请求验证失败
                        JSONObject result = new JSONObject();
                        result.put("result", "bad");
                        return result;
                    }
                    case 2: {
                        //设定时间戳
                        Timestamp timestamp = new Timestamp(new Date().getTime());
                        //存储路况报告
                        boolean insertResult =  drivingReportService.insertDrivingReport(data, data.getString("pId"), timestamp);
                        if (insertResult){
                            System.out.println("存储路况报告"+data.getString("pId")+"成功");
                            System.out.println("路况报告内容:"+data);
                            //存储成功
                            RSUReportRequestValidCount_temp++;
                            RSUReportRequestValidCount++;
                            JSONObject result = new JSONObject();
                            result.put("result", "success");
                            return result;
                        }else {
                            //存储失败
                            JSONObject result = new JSONObject();
                            result.put("result", "error");
                            return result;
                        }
                    }
                    default: {
                        //默认为失败
                        JSONObject result = new JSONObject();
                        result.put("result", "error");
                        return result;
                    }
                }
            }else {
                //验证公钥签名失败
                JSONObject result = new JSONObject();
                result.put("result", "error");
                return result;
            }
        } catch (Exception e) {
            //有异常则返回失败
            JSONObject result = new JSONObject();
            result.put("result", "error");
            return result;
        }
    }

}