package com.pisim.rsu.controller;

import com.alibaba.fastjson.JSONObject;
import com.pisim.rsu.Out;
import com.pisim.rsu.bean.DrivingReport;
import com.pisim.rsu.parameterUtil.parameter;
import com.pisim.rsu.service.DrivingReportService;
import com.pisim.rsu.utils.CongestionUtil;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.jpbc.PairingParameters;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;
import it.unisa.dia.gas.plaf.jpbc.pairing.a1.TypeA1CurveGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/GetTest")
public class TestController {
    @Autowired
    DrivingReportService drivingReportService;

    @RequestMapping(path = "sendATRtoTMSP", method = RequestMethod.GET)
    public JSONObject[] sendATRtoTMSP() {
        CongestionUtil congestionUtil = new CongestionUtil();
        JSONObject[] ATR = congestionUtil.generateATR(drivingReportService);
        congestionUtil.sendATRToTMSP(ATR);
        return ATR;
    }

    @RequestMapping(path = "/getAllReport", method = RequestMethod.GET)
    public JSONObject sendATRtoTMSPP() {
        List<DrivingReport> drivingReportList = drivingReportService.getDrivingReportList(false);
        List<JSONObject> drivingReportJsonList = new ArrayList<>();
        drivingReportService.filterFalseDrivingReport();
        for (DrivingReport drivingReport : drivingReportList) {
            drivingReportJsonList.add(JSONObject.parseObject(drivingReport.getReport_string()));
        }
        return drivingReportJsonList.get(0);
    }

    public static void getPairingParameter() {
        long startTime = System.currentTimeMillis();
        // 初始化pairing曲线
        TypeACurveGenerator typeACurveGenerator = new TypeACurveGenerator(160, 512);//rBit是Zp中阶数p的比特长度；qBit是G中阶数的比特长度
        // 初始化pairing参数
        PairingParameters pairingParameters = typeACurveGenerator.generate();
        // 将pairing参数写入到文件中
        Out out = new Out("./config/b.properties");
        out.println(pairingParameters);
        long endTime = System.currentTimeMillis();
        System.out.println(endTime - startTime);
    }

    @RequestMapping(path = "/filterFalseDrivingReport", method = RequestMethod.GET)
    public JSONObject filterFalseDrivingReport() {
//        for (int i = 0; i < 100; i++) {
        drivingReportService.filterFalseDrivingReport();
//        }
//        System.out.println("执行30次构造加权图总时间"+ parameter.totalGenerateGraphTime);
//        System.out.println("执行30次过滤总时间"+ parameter.totalIterationTime);
//        parameter.totalIterationTime = 0;
//        parameter.totalGenerateGraphTime = 0;
        JSONObject a = new JSONObject();
        a.put("aa", "aa");
        return a;
    }
}
