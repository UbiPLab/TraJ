package com.pisim.rsu.encryption;

import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class Hash {
    public static String sha256(String bigInteger) {
        long startTime = System.nanoTime();
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            //生成待加密字符串
            String input = bigInteger;//.toString();
            //执行加密
            for (int i = 0; i < 1000; i++) {
                messageDigest.update(input.getBytes());
            }
            //获取并输出加密结果
            BigInteger out = new BigInteger(1, messageDigest.digest());
            long endTime = System.nanoTime();
           // System.out.println("哈希算法耗时:"+(endTime - startTime));
            //返回加密结果
            //System.out.println("哈希结果"+out.toString());
            return out.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }
    public static byte[] sha128_byte(String input) {
        long startTime = System.nanoTime();
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
            // 调用digest方法，进行加密操作
            byte[] cipherBytes = messageDigest.digest(input.getBytes());
            return cipherBytes;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static byte[] sha256_byte(String input) {
        long startTime = System.nanoTime();
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            // 调用digest方法，进行加密操作
            byte[] cipherBytes = messageDigest.digest(input.getBytes());
            return cipherBytes;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Hmac sha 256
    public static String HMACSHA256(String data, byte[] key) throws Exception {
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secret_key = new SecretKeySpec(key, "HmacSHA256");
        sha256_HMAC.init(secret_key);
        byte[] array = sha256_HMAC.doFinal(data.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte item : array) {
            sb.append(Integer.toHexString((item & 0xFF) | 0x100).substring(1, 3));
        }
        return sb.toString().toLowerCase();
    }
    public static void main(String[] args) {
        String[] codeArray = {"0", "01", "02", "03", "04", "011",
                "012", "021", "022", "023", "032", "0121",
                "0122", "0221", "0222", "0223", "0322","01212",
                "01221", "01222", "012223", "03222", "032221"};
        String[] roadArray = {"wx4g0fk",
                "wx4g0fkwx4g0fswx4g0fuwx4g0ghwx4g0gkwx4g0gswx4g0guwx4g0uh",
                "wx4g0fkwx4g0fmwx4g0fqwx4g0frwx4g142wx4g143wx4g146wx4g147wx4g14k",
                "wx4g0fkwx4g0fhwx4g0cuwx4g0cswx4g0ckwx4g0ch",
                "wx4g0fkwx4g0f7wx4g0f6",
                "wx4g0guwx4g0uhwx4g0ukwx4g0uswx4g0uuwx4g0vhwx4g0vkwx4g0vs",
                "wx4g0uhwx4g0ujwx4g0unwx4g0gywx4g0gzwx4g15bwx4g15cwx4g1h1wx4g15fwx4g1h4wx4g1h5wx4g15gwx4g1hh",
                "wx4g14kwx4g14swx4g14uwx4g15hwx4g15kwx4g15swx4g15uwx4g1hh",
                "wx4g14kwx4g14mwx4g14qwx4g14rwx4g162wx4g163wx4g166wx4g167",
                "wx4g14kwx4g14hwx4g11uwx4g11swx4g11kwx4g11mwx4g11hwx4g11j",
                "wx4g0chwx4g0cjwx4g0cnwx4g0cpwx4g110wx4g111wx4g114wx4g115wx4g11hwx4g11j",
                "wx4g15uwx4g1jswx4g1jkwx4g1jhwx4g1huwx4g1hswx4g1hkwx4g1hh",
                "wx4g1hhwx4g1hjwx4g15vwx4g1hnwx4g15ywx4g1hpwx4g1k0wx4g1k1wx4g1k4wx4g1k5",
                "wx4g167wx4g16ewx4g16gwx4g175wx4g177wx4g17ewx4g17dwx4g17f",
                "wx4g167wx4g16kwx4g16mwx4g16qwx4g16rwx4g1d2wx4g1d3",
                "wx4g167wx4g165wx4g13gwx4g13ewx4g137wx4g135",
                "wx4g11jwx4g11nwx4g11pwx4g130wx4g131wx4g134wx4g135",
                "wx4g1jswx4g1jtwx4g1jwwx4g1jxwx4g1m8wx4g1m9wx4g1md",
                "wx4g1k5wx4g1k6wx4g1kdwx4g1kfwx4g1m4wx4g1m6wx4g1md",
                "wx4g1k5wx4g1khwx4g1kjwx4g1knwx4g1kpwx4g1s0",
                "wx4g1ecwx4g1e9wx4g1e3wx4g1e1wx4g1dcwx4g1d9wx4g1d3",
                "wx4g135wx4g13hwx4g13jwx4g13nwx4g13pwx4g190wx4g191",
                "wx4g191wx4g193wx4g199wx4g19cwx4g1d1wx4g1d3"
        };
        for (int i = 0 ; i<codeArray.length;i++){
            System.out.println(codeArray[i]+":"+sha256(codeArray[i]).length()+":"+roadArray[i]);
        }
    }
}
